@php
$randStr = App\generateRandomString();

if (get_sub_field('vimeo_url')):
    $vimeo_media = get_sub_field('vimeo_url');
    $image = get_sub_field('video_cover');
    $type = 'vimeo';
@endphp
    <div class="container py-20">
    <div class="w-full">
        <div class="vimeo-wrapper">
            <div class="content ready" id="video-{{$randStr}}">
                @php
                echo do_shortcode("[spawn_vimeo id=".$vimeo_media."]");
                @endphp
            </div>
            
            <div class="video-cover bg-center bg-no-repeat bg-cover" style="background-image: url({{$image}})" id="video-{{$randStr}}-cover">
                <img src="@asset("images/play.png")" alt=""
                    class="video-play-button cursor-pointer hover:opacity-75"
                    data-target="#video-{{$randStr}}"
                >
            </div>
        </div>
    </div>
</div>
@php
endif
@endphp
