<div class="container">
    <div class="w-full py-20 border-container: container rounded-xl"><img src="{{ get_sub_field('image') }}"></div>
</div>