<section class="container py-10 flex flex-wrap lg:flex-no-wrap lg:w-full items-center {{ get_sub_field('position') === 'right' ? 'lg:flex-row-reverse' : ''}}">

    @if(get_sub_field('image_shape') === 'round')
      <div class="wrapper w-5/6 ml-10 self-center pt-10 lg:pt-0 xl:pt-16 lg:self-start mb-10 lg:mb-0 {{ get_sub_field('position') === 'right' ? 'lg:ml-20' : 'lg:mr-20'}}">
        <div class="square">
          <div class="blue_circle {{ get_sub_field('circle') === 'no' ? 'hidden' : ''}} {{ get_sub_field('circle_color') }}"></div>
          <div class="circle-outer-outset"></div>
          <div class="circle-outer-inset"></div>
            <div class="circle-image-wrapper">
                <div
                class="circle-image"
                style="background-image: url('{{ get_sub_field('image') }}')"></div>
            </div>
        </div>
      </div>
    @else
    <div class="w-full self-center lg:self-start mb-10 lg:mb-0 {{ get_sub_field('position') === 'right' ? 'lg:ml-20' : 'lg:mr-20'}}">
      {{-- <div class="square">
        <div class="blue_circle {{ get_sub_field('circle') === 'no' ? 'hidden' : ''}} {{ get_sub_field('circle_color') }}"></div>
        <div class="square-outer-outset"></div>
        <div class="square-outer-inset"></div>
          <div class="circle-image-wrapper"> --}}
      <div class="videoimage"><img src="{{ get_sub_field('image') }}"></div>
          {{-- </div>
      </div> --}}
    </div>
    @endif

    <div class="w-full flex flex-col">
        <div class="text-lg lg:text-xl text-b1 leading-none">{{ get_sub_field('title') }}</div>
        <div class="pt-10 lg:text-md text-b1 leading-normal">{{ get_sub_field('sub_title') }}</div>
        <div class="pt-10 text-xs lg:text-base text-b1 text-opacity-75">{!! get_sub_field('content') !!}</div>

        @php
        if( have_rows('button') ):
          // Loop through rows.
        while( have_rows('button') ) : the_row();
        @endphp

        <div class="button mt-5 {{ get_sub_field('button_color') === 'white' ? 'button-white' : '' }} ">
          <a href="{{ get_sub_field('button_link') }}"><div class="button_label text-xs lg:text-base ">{{ get_sub_field('button_label') }}</div></a>
        </div>

        @php
        // End loop.
          endwhile;
          endif;
        @endphp
    </div>

</section>
