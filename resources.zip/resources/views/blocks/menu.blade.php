<section class="py-10">
  <div class='container'>
    <div class="flex flex-col-reverse flex-wrap lg:flex-row lg:flex-no-wrap items-center justify-between lg:w-full">
      <div class="w-full mt-10 lg:w-1/2 lg:pr-10 lg:mt-0">
          <div class="text-lg lg:text-xl text-b1 leading-none">{{ get_sub_field('title') }}</div>
          <div class='text-xs lg:text-base text-b1 text-opacity-75 pt-8 pb-16'>{!! get_sub_field('content') !!}</div>

          <div class="flex items-center">


          @php
            if( have_rows('button') ):
              // Loop through rows.
              while( have_rows('button') ) : the_row();
          @endphp

            <div class="button mr-5 {{ get_sub_field('button_color') === 'white' ? 'button-white' : '' }} ">
              <a href="{{ get_sub_field('button_link') }}"><div class="button_label text-xs lg:text-base ">{{ get_sub_field('button_label') }}</div></a>
            </div>


          @php
              // End loop.
              endwhile;
            endif;
          @endphp
          </div>
      </div>

      <div class="wrapper w-5/6 pt-10 lg:pt-0 lg:w-1/2 ml-10">
        <div class="square">
          <div class="blue_circle {{ get_sub_field('circle') === 'no' ? 'hidden' : ''}} {{ get_sub_field('circle_color') }}"></div>
          <div class="circle-outer-outset"></div>
          <div class="circle-outer-inset"></div>
          <div class="circle-image-wrapper">
            <div
              class="circle-image"
              style="background-image: url('{{ get_sub_field('image') }}')"></div>
          </div>
        </div>
      </div>

    @if(get_sub_field('image_shape') === 'circle')
      {{-- //circle image here --}}
    @else
      {{-- // default image here (retangular) --}}
    @endif

    </div>
  </div>
</section>

<?php

