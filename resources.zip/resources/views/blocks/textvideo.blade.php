<section class="container py-10 flex flex-wrap justify-between {{ get_sub_field('position') === 'right' ? 'lg:flex-row-reverse' : ''}}">
    <div class="w-full xl:w-1/2 mb-8 xl:mb-0{{ get_sub_field('position') === 'right' ? 'ml-0 lg:ml-10' : 'mr-0 lg:mr-10'}}">
      <div class="square">
        <div class="blue_circle {{ get_sub_field('circle') === 'no' ? 'hidden' : ''}} {{ get_sub_field('circle_color') }}"></div>
        <div class="rec-outer-outset {{ get_sub_field('box_shadow') === 'no' ? 'hidden' : ''}} fix"></div>
        <div class="rec-outer-inset {{ get_sub_field('box_shadow') === 'no' ? 'hidden' : ''}} fix"></div>
        <div class="circle-image-wrapper fix">
          @php
              $randStr = App\generateRandomString();
              $type = '';
              $image = get_sub_field('image');

              if (get_sub_field('vimeo_url')):
                  $vimeo_media = get_sub_field('vimeo_url');
                  $type = 'vimeo';
                  @endphp
                      <div class="vimeo-wrapper">
                          <div class="content ready" id="video-{{$randStr}}">
                  @php
                      echo do_shortcode("[spawn_vimeo id=".$vimeo_media."]");
                  @endphp
                          </div>

                          <div class="bg-center bg-no-repeat bg-cover video-cover" style="background-image: url({{$image}})" id="video-{{$randStr}}-cover">
                              <img src="@asset("images/play.png")" alt=""
                                  class="video-play-button cursor-pointer hover:opacity-75 w-1/4"
                                  data-target="#video-{{$randStr}}"
                              >
                          </div>
                      </div>
                  @php
              else:
                  @endphp
                  <div class="videoimage"><img src="{{ get_sub_field('image') }}"></div>
                  @php
              endif
          @endphp
        </div>
      </div>

    </div>
    <div class="w-full xl:w-5/12 mt-10 lg:m-0 leading-none {{ get_sub_field('position') === 'right' ? 'lg:mr-10' : 'lg:ml-10'}} -mt-24 md:-mt-32 lg:-mt-48 xl:mt-0">
        <div class="text-lg lg:text-xl text-b1 leading-none">{{ get_sub_field('title') }}</div>
        <div class="lg:text-md text-b1 pt-10 leading-normal">{{ get_sub_field('sub_title') }}</div>
        <div class="text-xs lg:text-base text-b1 text-opacity-75 pt-10">{!! get_sub_field('content') !!}</div>

        @php
        if( have_rows('button') ):
          // Loop through rows.
        while( have_rows('button') ) : the_row();
        @endphp

        <div class="button mt-5 {{ get_sub_field('button_color') === 'white' ? 'button-white' : '' }} ">
          <a href="{{ get_sub_field('button_link') }}"><div class="button_label text-xs lg:text-base ">{{ get_sub_field('button_label') }}</div></a>
        </div>

        @php
        // End loop.
          endwhile;
          endif;
        @endphp

      </div>
</section>

