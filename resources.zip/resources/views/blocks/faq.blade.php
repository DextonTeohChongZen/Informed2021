<div class="container">
  <div class="w-full lg:w-1/2 flex flex-wrap">

    @php
      if( have_rows('group') ):
      // Loop through rows.
      while( have_rows('group') ) : the_row();
    @endphp

    <div class="my-20">
      <div class="pl-10 text-md">{{ get_sub_field('group_title') }}</div>

      <div class="flex flex-col">
        @php
            if( have_rows('qanda') ):
              // Loop through rows.
              while( have_rows('qanda') ) : the_row();
        @endphp

        <div class="collapsible">{!! get_sub_field('question') !!}</div>
        <div class="example">
          <p>{!! get_sub_field('answer') !!}</p>
        </div>

        @php
        // End loop.
          endwhile;
        endif;
        @endphp
      </div>

        @php
        // End loop.
          endwhile;
        endif;
      @endphp
  </div>

      {{-- <div id="form" class="pl-10 py-4">
        {{ gravity_form( get_sub_field('sub-form'), false, false, false, '', true, 20) }}
      </div> --}}

  </div>
</div>
