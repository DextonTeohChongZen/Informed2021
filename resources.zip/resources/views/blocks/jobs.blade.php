<section class="container flex flex-wrap items-stretch lg:flex-no-wrap">
    <div class="w-full mt-10 mb-10 lg:w-2/3 lg:mt-0 lg:pr-10">
        <div class="text-lg lg:text-xl text-b1 leading-none">{{ get_sub_field('title') }}</div>
        <div class="mt-8 text-b1">{{ get_sub_field('sub_title') }}</div>
        <div class="mt-6 text-xs text-grey">{!! get_sub_field('content') !!}</div>

        <div class="mt-6 flex-col items-center">

        @php
            if( have_rows('button') ):
              // Loop through rows.
              while( have_rows('button') ) : the_row();
        @endphp

        <div class="button mt-8 mr-5 {{ get_sub_field('button_color') === 'white' ? 'button-white' : '' }} ">
            <a href="{{ get_sub_field('button_link') }}"><div class="button_label">{{ get_sub_field('button_label') }}</div></a>
        </div>
    

        @php                 
              // End loop.
              endwhile;
            endif;
        @endphp
        </div>
    </div>

    <div class="wrapper w-3/4 pt-20 self-center lg:self-start lg:pl-10 lg:pt-10 lg:1/3">
        <div class="square">
          <div class="circle-outer-outset"></div>
          <div class="circle-outer-inset"></div>
          <div class='blue_circle'></div>
            <div class="circle-image-wrapper">
                <div 
                class="circle-image" 
                style="background-image: url('{{ get_sub_field('image') }}')"></div>
            </div>
        </div>
    </div>

</section>




