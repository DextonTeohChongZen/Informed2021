<section class="container flex py-10">
    <div class="w-1/2">
        <div class="text-lg lg:text-xl text-b1 mb-10 leading-none">{{ get_sub_field('title') }}</div>
        <div class="text-xs lg:text-base text-b1 mt-10 leading-normal">{{ get_sub_field('sub_title') }}</div>
    @php
    if( have_rows('button') ):
      // Loop through rows.
    while( have_rows('button') ) : the_row();
    @endphp

    <div class="button mt-5 {{ get_sub_field('button_color') === 'white' ? 'button-white' : '' }} ">
      <a href="{{ get_sub_field('button_link') }}"><div class="button_label text-xs lg:text-base ">{{ get_sub_field('button_label') }}</div></a>
    </div>

    @php
    // End loop.
      endwhile;
      endif;
    @endphp
      </div>

    <div class="w-1/2 ml-20 flex flex-wrap">
        <div class="text-xs lg:text-base text-b1 text-opacity-75">{!! get_sub_field('content') !!}</div>
    </div>

</section>
