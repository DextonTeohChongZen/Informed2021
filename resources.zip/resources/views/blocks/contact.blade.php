<div class="container py-10">
    <div class="flex flex-wrap">
        <div class="w-full lg:w-5/12">
            <div class="text-xl text-b1 mb-10">{{get_sub_field('title')}}</div>
            <div class="text-md text-b1 mb-10">{!!get_sub_field('intro_text')!!}</div>
            <div class="text-b1 mb-10">{!!get_sub_field('content')!!}</div>
            {{-- <div class=" text-b1">{!! get_field('address', 'options')['company_address']!!}</div>
            <div class=" text-b1">{{ get_field('address', 'options')['company_tel']}}</div>
            <div class=" text-b1"><a href="{{ get_field('address', 'options')['company_email']}}" class="reset opacity-hover">{{ get_field('address', 'options')['company_email']}}</a></div> --}}
        </div>

        <div class='w-full lg:w-1/12'></div>


        <div class='w-full lg:w-6/12'>
            <div class="text-b1 text-opacity-75 mb-6">{!!get_sub_field('form_description')!!}</div>

            <div class="informed-gform">
              <?php
                  gravity_form( get_sub_field('form_id'), false, false, false, null, true, 10, true );
                  ?>
              @php
              @endphp

            </div>
        </div>
    </div>
</div>


