<!doctype html>
<html {!! get_language_attributes() !!}>
  @include('partials.head')
  <body @php body_class() @endphp>
    @php
      $special = false;

      if (get_page_template_slug() === 'views/template-custom-logo.blade.php') {
        $special = true;
      }
    @endphp
    {{-- <h1>{{get_page_template_slug()}}</h1> --}}

    @php do_action('get_header') @endphp

    @if (!$special)
      @include('partials.header')
    @endif

    <div class="wrap" role="document">
      <div class="content">
        <main class="main">
          @yield('content')
        </main>
        @if (App\display_sidebar())
          <aside class="sidebar">
            @include('partials.sidebar')
          </aside>
        @endif
      </div>
    </div>

    @if (!$special)
      @include('partials.footer')
    @endif
    @php wp_footer() @endphp

    <script src="https://player.vimeo.com/api/player.js"></script>
    <script>
      $ = jQuery;
      $(document).ready(function(){
          $('.video-play-button').on('click', function(){
        const target = $(this).data('target');
        $(target).removeClass('ready');
        $(target+'-cover').hide();

        var iframe = $(target + ' iframe');
        console.log('iframe', iframe);

        var player = new Vimeo.Player(iframe);

        player.play();

        player.on('play', function() {
          console.log('Played the video');
        });
      });

      });
    </script>
  </body>
</html>
