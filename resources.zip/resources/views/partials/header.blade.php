<header class="flex items-center lg:px-4 xl:px-0">
  <div class="container">

    <div class="nav-wrapper flex items-center justify-between">

      <div class="nav-bar flex-grow hidden lg:flex items-center justify-between">
        <a class="brand" href="{{ home_url('/') }}"><img src="@asset("images/informed.gif")" alt="Informed"></a>
        <nav class="nav-primary">
          @if (has_nav_menu('primary_navigation'))
            {!! wp_nav_menu(['theme_location' => 'primary_navigation', 'menu_class' => 'nav']) !!}
          @endif
        </nav>
      </div>
      <div class="nav-log-in hidden mr-8 lg:block pl-8 xl:pl-16 whitespace-no-wrap"><a href="https://informed.plus/login" class="reset">Log in</a></div>

      <a class="brand lg:hidden" href="{{ home_url('/') }}"><img src="@asset("images/informed.gif")" alt="Informed"></a>
      <span class="menu-toggle collapse-toggle mm lg:hidden text-xs text-b1"
        data-target="#mobile-menu"
        data-group=".mm"
        data-limit="any"
        >Menu</span>
    </div>

    <div class="collapse mm close lg:hidden" id="mobile-menu">
      <div class="mobile-menu nav-primary pb-8">
        @if (has_nav_menu('primary_navigation'))
          {!! wp_nav_menu(['theme_location' => 'primary_navigation', 'menu_class' => 'nav text-xs']) !!}
        @endif
        <div class="menu-log-in block lg:hidden">
          <a href="https://informed.plus/login" class="reset">Log in</a>
        </div>
      </div>
    </div>

  </div>
</header>
