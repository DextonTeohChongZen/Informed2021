<footer class="containerfoot py-16">
  <div class="container text-white leading-snug">
    <div class="w-3/5 sm:w-full mt-5 mb-20 flex items-center"><img src="@asset('images/img5.png')"></div>

    <div class="flex flex-wrap">
        <div class="w-full sm:w-1/2 xl:w-4/12 text-xs">
          @if (get_field('address', 'options')['company_name'])
            <div class="mb-5">{{ get_field('address', 'options')['company_name']}}</div>
          @endif

          @if (get_field('address', 'options')['company_address'])
            <div>{!! get_field('address', 'options')['company_address']!!}</div>
          @endif

          @if (get_field('address', 'options')['company_tel'])
            <div>{{ get_field('address', 'options')['company_tel']}}</div>
          @endif

          @if (get_field('address', 'options')['company_email'])
            <a href="mailto:{{ get_field('address', 'options')['company_email']}}" class="text-white">{{ get_field('address', 'options')['company_email']}}</a>
          @endif

          @if (get_field('button', 'options'))
            <div class="mt-10">
              <a href="{{get_field('button', 'options')['url']}}" class="button button-white">
                <div class="button_label">{{get_field('button', 'options')['title']}}</div>
            </a>
            </div>
          @endif
        </div>

      <div class="w-full sm:w-1/2 xl:w-2/12">
        @if (has_nav_menu('footer_navigation'))
          <div class="mb-5">Menu</div>
          <div>
            {!! wp_nav_menu(['theme_location' => 'footer_navigation', 'menu_class' => 'footer_nav text-xs']) !!}
          </div>
        @endif
      </div>

      <div class="w-full sm:w-1/2 xl:w-3/12">
        <div class="text-xs xl:mt-12 text-white">
          @if (have_rows('footer_links', 'options'))
            <ul class="footer_nav">
              @while (have_rows('footer_links', 'options'))
                @php the_row() @endphp
                <li><a href="{{get_sub_field('link')['url']}}">{{get_sub_field('link')['title']}}</a></li>
              @endwhile
            </ul>
          @endif
        </div>
      </div>

      <div class="w-full sm:w-1/2 xl:w-3/12">
        @if (have_rows('social_media', 'options'))
          <div>Social Media</div>
          <div class="flex mt-2">
            @while (have_rows('social_media', 'options'))
                @php the_row() @endphp
                <a href="{{get_sub_field('url')}}" target="_blank" class="mr-2"><img src="{{get_sub_field('icon')}}" alt=""></a>
              @endwhile
          </div>
        @endif
      </div>
    </div>
  </div>
</footer>

{{-- <div class="fixed bottom-0 left-0 bg-white p-5 text-xl">
  <div class="hidden sm:hidden">
    Mobile
  </div>
  <div class="hidden sm:block md:hidden">
    SM
  </div>
  <div class="hidden md:block lg:hidden">
    MD
  </div>
  <div class="hidden lg:block xl:hidden">
    LG
  </div>
  <div class="hidden xl:block">
    XL
  </div>
</div> --}}
