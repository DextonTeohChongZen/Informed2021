{{--
  Template Name: Custom Logo Template
--}}

@extends('layouts.app')

@section('content')
  @while(have_posts()) @php the_post() @endphp

    @php
    $bgColor = get_field('background_color');
    $textColor = get_field('text_color');
    $logo = get_field('logo');
    $footerText = get_field('footer_text');

    @endphp

    <div class="custom-logo-page_header py-4 lg:py-8 mb-8" style="background-color: {{$bgColor}}; box-shadow: 0px 0px 20px 0px #000000;">
      <div class="custom-logo-page_header-logo bg-center bg-no-repeat bg-contain" style="background-image: url({{$logo}})"></div>
    </div>

    @include('partials.flexible')

    <div class="custom-logo-page_footer lg:flex lg:justify-center lg:items-center px-4 py-8 lg:py-8 mt-8" style="background-color: {{$bgColor}}; box-shadow: 0px 0px 20px 0px #000000;">
      <img src="{{$logo}}" alt="" class="lg:h-full lg:w-auto lg:mr-8 mb-8 lg:mb-0 custom-logo-page_footer-logo">
      <div class="text-xs text-center lg:text-left" style="color: {{$textColor}}">{!!$footerText!!}</div>
    </div>
  @endwhile
@endsection
