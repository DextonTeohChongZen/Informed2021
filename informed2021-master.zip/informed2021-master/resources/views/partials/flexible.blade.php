@php
// Check value exists.
if( have_rows('flexible_layout') ):
  // Loop through rows.
  while ( have_rows('flexible_layout') ) : the_row();
    // Case: Paragraph layout.
    if( get_row_layout() == 'image_copy' ):
      @endphp
        @include('blocks.menu')
      @php
    // Case: text
    elseif( get_row_layout() == 'text' ):
      @endphp
        @include('blocks.text')
      @php
    // Case: text image
    elseif( get_row_layout() == 'text_image' ):
      @endphp
        @include('blocks.textimage')
      @php
    // Case: image
    elseif( get_row_layout() == 'image' ):
      @endphp
        @include('blocks.image')
      @php
    // Case: logo parade
    elseif( get_row_layout() == 'logo_parade' ):
      @endphp
        @include('blocks.logoparade')
      @php
    // Case: usps
    elseif( get_row_layout() == 'usp' ):
      @endphp
        @include('blocks.usp')
      @php
    // Case: news
    elseif( get_row_layout() == 'news' ):
      @endphp
        @include('blocks.news')
      @php
    // Case: feed
    elseif( get_row_layout() == 'feed' ):
      @endphp
        @include('blocks.feed')
      @php
    // Contact
    elseif( get_row_layout() == 'contact' ):
      @endphp
        @include('blocks.contact')
      @php
    // Case: video
    elseif( get_row_layout() == 'video' ):
      @endphp
        @include('blocks.video')
      @php
    // Case: text video
    elseif( get_row_layout() == 'text_video' ):
      @endphp
        @include('blocks.textvideo')
      @php
    // Case: FAQ
    elseif( get_row_layout() == 'faq' ):
      @endphp
        @include('blocks.faq')
      @php
    endif;
    // End loop.
  endwhile;
endif;
@endphp
