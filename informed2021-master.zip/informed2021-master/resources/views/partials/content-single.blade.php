<div class="media-back">
  <div class="container">
      <a href="javascript:window.history.back()" class="reset opacity-hover back-to-overview">Terug</a>
  </div>
</div>

<article @php post_class() @endphp>
  @php
    $type = '';
    $imageURL = '';

    if (get_field('vimeo_id')) {
      $vimeo_media = get_field('vimeo_id');
      $type = 'vimeo';

      // For getting cover image from Vimeo
      // $video_id = substr($vimeo_media, strrpos($vimeo_media, '/') + 1);
      // $hash = unserialize(file_get_contents("http://vimeo.com/api/v2/video/$video_id.php"));
      // $imageURL = $hash[0]['thumbnail_large'];
    } else {
      $imageURL = get_the_post_thumbnail_url();
    }
  @endphp

  <div class="container">
      <div class="news-post pb-56">
        @if ($type == 'vimeo')
          <div class="news-post_video mb-5">
            <div class="content">@php echo do_shortcode("[spawn_vimeo id=".$vimeo_media."]"); @endphp</div>
          </div>
        @else
          <div class="news-post_thumb mb-5 {{ $imageURL ? '' : 'blank'}}" style="{{ $imageURL ? 'background-image: url('.$imageURL.')' : ''}}"></div>
        @endif

        <div class="news-post_date text-grey text-xs">@php $post_date = get_the_date( 'j F Y' ); echo $post_date; @endphp</div>
        <h1 class="entry-title text-md font-bold mb-10">{!! get_the_title() !!}</h1>
        <div class="news-post_content">
          @php the_content() @endphp
        </div>
      </div>
  </div>
</article>
