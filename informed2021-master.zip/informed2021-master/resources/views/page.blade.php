@extends('layouts.app')

@section('content')
  @while(have_posts()) @php the_post() @endphp
    @php
    if (get_field('back_to_button') === 'yes'):
    @endphp
      <div class="container">
        <div class="text-xs lg:text-base text-grey cursor-pointer" onclick="window.history.go(-1); return false;">< Terug</div>
      </div>
    @php
    endif
    @endphp

    @include('partials.flexible')

    {{-- Case: text image
    elseif( get_row_layout() == 'text_image_2' ):
      @endphp
        @include('blocks.textimage2')
      @php

    Case: jobs
    elseif( get_row_layout() == 'jobs' ):
      @endphp
        @include('blocks.jobs')
      @php

    {@include('blocks.contact')
    @include('partials.page-header')
    @include('blocks.contact')
    @include('blocks.login')
    @include('partials.content-page')
    @include('partials.footer') --}}

  @endwhile
@endsection

