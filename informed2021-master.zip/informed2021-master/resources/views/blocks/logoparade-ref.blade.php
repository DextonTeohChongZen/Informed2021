<div class="container py-40">
    <div class="py-20 mx-40 flex flex-col items-center">
        <div class="mb-5 text-center"><h3>{{ get_sub_field('title') }}</h3></div>
        <div class="w-3/5 text-center"><h4>{{ get_sub_field('sub_title') }}</h4></div>
    </div>

    <div class='flex flex-wrap items-center justify-between mt-5'>

      {{-- Logo 1 --}}
        <div class="w-full sm:w-1/2 xl:w-1/4 flex justify-center">
            <div class="mb-8 xl:mb-0">
                <div class="logowrapper">
                    <div class="square">
                        <div class="circle-outer-outset"></div>
                        <div class="circle-outer-inset"></div>
                        <div class="circle-image-wrapper">
                            <div 
                            class="logo-image" 
                            style="background-image: url('{{ get_sub_field('image_1') }}')"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>


      @if(get_sub_field('image_shape') === 'circle')
      {{-- //circle image here --}}
      @else
      {{-- // default image here (retangular) --}}
      @endif
        
    </div>
</div>