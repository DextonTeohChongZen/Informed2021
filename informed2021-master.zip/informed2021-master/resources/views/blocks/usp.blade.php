<div class="container py-10">
    <div class="">
        <div class="w-1/3 mb-20 text-lg lg:text-xl text-b1 leading-none">{{ get_sub_field('title') }}</div>

        <div class="w-full flex flex-col items-center lg:flex-no-wrap lg:flex-row lg:items-left">
            <div class="w-full lg:w-1/2">
                <div class="relative">
                    <div class='inline px-10 py-8 ml-5 bg-white rounded-xl lg:text-md text-b1 leading-normal'>{{ get_sub_field('group_title_1') }}</div>
                    <div class=" pt-10 pb-20 px-8 bg-green bg-opacity-25 rounded text-xs text-b1">{!! get_sub_field('content_1') !!}</div>
                    <img src="{{ get_sub_field('image_1') }}" class="shape1">
                </div>

                <div class="mt-32 relative">
                    <div class='inline px-10 py-8 ml-5 bg-white rounded-xl lg:text-md text-b1 leading-normal'>{{ get_sub_field('group_title_3') }}</div>
                    <div class=" pt-10 pb-20 px-8 bg-darkblue bg-opacity-25 rounded text-xs text-b1">{!! get_sub_field('content_3') !!}</div>
                    <img src="{{ get_sub_field('image_3') }}" class="shape3">
                </div>
            </div>

            <div class="w-full lg:w-1/2 lg:ml-40">
                <div class="mt-32 relative lg:text-right">
                    <div class='inline px-10 py-8 mr-10 bg-white rounded-xl lg:text-md text-b1 leading-normal'>{{ get_sub_field('group_title_2') }}</div>
                    <div class=" pt-10 pb-40 px-8 bg-pink bg-opacity-25 rounded text-xs text-b1 text-left">{!! get_sub_field('content_2') !!}</div>
                    <img src="{{ get_sub_field('image_2') }}" class="shape2">
                </div>
            </div>
        </div>
    </div>
</div>

