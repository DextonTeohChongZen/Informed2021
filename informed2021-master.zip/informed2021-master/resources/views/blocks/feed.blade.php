<div class="container py-10">
    <div class="flex flex-wrap justify-start news-overview -mx-4">
      @php
      // Check rows exists.
      if( have_rows('feed_content') ):

          // Loop through rows.
          while( have_rows('feed_content') ) : the_row();
      @endphp

          <a href="{{get_sub_field("link")}}" class="w-full sm:w-1/2 xl:w-1/3 px-4 rounded inline-block mb-8 text-grey">
          <div
            class="feed-image w-full bg-cover bg-center bg-no-repeat"
            style="background-image: url('{{ get_sub_field('image') }}')"></div>
          <div class="mt-5 text-base text-b1 leading-none">{{get_sub_field("title")}}</div>
          <div class="mt-5 text-xs text-b1 text-opacity-75 break-words">{!! wp_trim_words(get_sub_field("content"), 15) !!}</div>
        </a>

      @php
          // End loop.
          endwhile;

      endif;
      @endphp
    </div>
</div>









