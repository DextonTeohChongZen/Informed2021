@php
  $paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
@endphp

<div class="container py-10">
  {{-- <h1>Paged {{$paged}}</h1> --}}
  <div class="flex flex-wrap justify-between news-overview -mx-4">

      @php
        $args = array(
          'post_type'              => array( 'post' ),
          'post_status'            => array( 'publish' ),
          'nopaging'               => false,
          'posts_per_page'         => '6',
          'paged'                  => $paged,
          'order'                  => 'DESC',
          'orderby'                => 'date',
        );

        $query = new WP_Query( $args );

        if ( $query->have_posts() ) {
          while ( $query->have_posts() ) {
            $query->the_post();

            $type = '';
            $imageURL = '';

            if (get_field('vimeo_id')) {
              $vimeo_media = get_field('vimeo_id');
              $type = 'vimeo';

              // $vimeo_media = 'https://vimeo.com/channels/staffpicks/241579722';
              // $video_id = '259411563'; // test dummy id

              $video_id = substr($vimeo_media, strrpos($vimeo_media, '/') + 1);
              $hash = unserialize(file_get_contents("https://vimeo.com/api/v2/video/$video_id.php"));
              $imageURL = $hash[0]['thumbnail_large'];
              $imageURL = str_replace('http://', 'https://', $imageURL);

              if(!$imageURL) {
                $imageURL = get_the_post_thumbnail_url();
              }
            } else {
              $imageURL = get_the_post_thumbnail_url();
            }
      @endphp

        <a href="{{get_the_permalink()}}" class="w-full sm:w-1/2 xl:w-1/3 px-4 rounded inline-block mb-8 text-grey">
          <div
            class="feed-image w-full bg-cover bg-center bg-no-repeat"
            style="background-image: url('{{ $imageURL }}')"></div>
          <div class="mt-5 text-base text-b1">{!! the_title() !!}</div>
          <div class="mt-5 text-sm text-b1 text-opacity-75 break-words">{!! wp_trim_words(get_the_content(), 15) !!}</div>
        </a>
      @php
        }
      }
      @endphp
    </div>
</div>

<div class="py-10 flex items-center justify-center">

  @php
    wp_pagenavi(array( 'query' => $query ));
    wp_reset_postdata();
  @endphp

</div>
