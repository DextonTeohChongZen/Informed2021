<div class="container">
    <div class="py-10 mx-20 flex flex-col items-center">
        <div class="mb-10 text-center text-md lg:text-lg text-b1">{{ get_sub_field('title') }}</div>
        <div class="w-full text-center lg:text-md text-b1 text-opacity-75">{{ get_sub_field('sub_title') }}</div>
    </div>

    <div class='flex flex-wrap items-center justify-start mb-20'>

    @php
    // Check rows exists.
    if( have_rows('logo') ):

        // Loop through rows.
        while( have_rows('logo') ) : the_row();
    @endphp

            <div class="w-full sm:w-1/2 xl:w-1/4 flex justify-center">
                <div class="mb-5">
                    <div class="logowrapper">
                        <div class="square">
                        <div class="circle-outer-outset"></div>
                        <div class="circle-outer-inset"></div>
                            <div class="circle-image-wrapper">

                              @if (get_sub_field('link'))
                                <a href="{{ get_sub_field('link')['url'] }}" target = '_blank' class='cursor-pointer'>
                              @endif
                                <div class="logo-image" style="background-image: url('{{ get_sub_field('image') }}')"></div>
                              @if (get_sub_field('link'))
                                </a>
                              @endif

                            </div>
                        </div>
                    </div>
                </div>
              </div>

    @php
        // End loop.
        endwhile;

    endif;
    @endphp
    </div>
</div>
