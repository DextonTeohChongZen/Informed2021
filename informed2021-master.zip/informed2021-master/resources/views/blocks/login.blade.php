<div class='container py-20'>
    <div class='flex items-center justify-center'>
        <div class='w-1/3'>
            <div class='text-xl text-b1'>Login</div>
            <div class='pt-10 text-b1 text-opacity-75'>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus molestie ex dictum, finibus quam placerat, posuere lectus. Nam maximus imperdiet varius.</div>

            <div class="pt-5 mb-6">
                <label class="block text-b1 text-opacity-75 text-xs font-bold mb-2" for="username">Username</label>
                <input class="shadow appearance-none border rounded w-full py-2 px-3 text-b1 text-opacity-75 leading-tight focus:outline-none focus:shadow-outline" id="username" type="text" placeholder="perry@poetfarmer.col">
            </div>

            <div class="pt-2 mb-6">
                <label class="block text-b1 text-opacity-75 text-xs font-bold mb-2" for="password">Password</label>
                <input class="shadow appearance-none border rounded w-full py-2 px-3 text-b1 text-opacity-75 mb-3 leading-tight focus:outline-none focus:shadow-outline" id="password" type="password" placeholder="*******">
            </div>

            <div class="flex">
                <div class="w-1/2 flex justify-start button button-green">
                    <div class="button_label">Login</div>
                </div>

                <div class="w-1/2 py-8 flex justify-end">
                    <div class="inline-block align-baseline text-xs underline" href="#">Forgot Password?</div>
                </div>
            </div>
        </div>
    </div>
</div>
