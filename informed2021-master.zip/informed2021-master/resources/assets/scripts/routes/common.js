export default {
  init() {
    // JavaScript to be fired on all pages

    // Gravity form hacks ///////////////////////////////////////////
    $('.informed-gform').each(function() {
      const gButton = $(this).find('.gform_button.button');
      const fakeButton = $(this).find('.gravity-fake-submit-button');

      fakeButton.html(gButton.val())
    })

    $('#gravity-fake-submit-button').on('click', function () {
      $(this).addClass('loading');
      $('.gform_wrapper form').trigger('submit');
    });

    jQuery(document).on('gform_post_render', function () {
      // code to trigger on form or form page render
      $('#gravity-fake-submit-button').removeClass('loading');
    });

    jQuery(document).on('gform_confirmation_loaded', function () {
      // code to be trigger when confirmation page is loaded
      $('#gravity-fake-submit-button').remove();
    });

    // WP Page navi hack //////////////////////////////////////////////
    if ($('.wp-pagenavi').length > 0) {
      if ($('.previouspostslink').length > 0) {
        $('.wp-pagenavi').prepend($('.previouspostslink'));
      }
    }

    // Collapse ////////////////////////////////////////////////////////
    // Initialized collapse elements
    $('.collapse').each(function () {
      var elm = $(this);
      var h = elm[0].scrollHeight;

      elm[0].style.height = h + 'px';
    });

    // When collapse toggle is clicked
    $('body').on('click', '.collapse-toggle', function () {
      var toggle = $(this);
      var group = $(this).data('group');
      var target = $($(this).data('target'));
      var limit = $(this).data('limit');

      if (limit === 'any') {
        if (!toggle.hasClass('active')) {
          $(group + '.collapse-toggle.active').removeClass('active');
          $(group + '.collapse')
            .not('.close')
            .addClass('close');
        }

        target.toggleClass('close');
        toggle.toggleClass('active');
      } else {
        $(group + '.collapse-toggle').removeClass('active');
        toggle.addClass('active');
        $(group + '.collapse').addClass('close');
        target.removeClass('close');
      }

      var slickTarget = $(this).data('slick');

      if (slickTarget !== undefined) {
        var slideIndex = $(this).data('goto');

        $(slickTarget).slick('slickGoTo', parseInt(slideIndex));
      }
    });

    // When window resize update collapse element height
    $(window).resize(function () {
      $('.collapse').each(function () {
        var elm = $(this);

        elm[0].style.height = 'auto';

        var h = elm[0].scrollHeight;

        elm[0].style.height = h + 'px';
      });
    });
    // Collapse //////////////////////////////////////////////////////// END
  },
  finalize() {
    // JavaScript to be fired on all pages, after page specific JS is fired
  },
};

// Collapsible //
var coll = document.getElementsByClassName('collapsible');
var i;

for (i = 0; i < coll.length; i++) {
  coll[i].addEventListener('click', function() {
    this.classList.toggle('active');
    var example = this.nextElementSibling;
    if (example !== null) {
      if (example.style.maxHeight){
        example.style.maxHeight = null;
      } else {
        example.style.maxHeight = example.scrollHeight + 'px';
      }
    }
  });
}

// var coll = document.getElementsByClassName('collapsible');
// var i;

// for (i = 0; i < coll.length; i++) {
//   coll[i].addEventListener('click', function() {
//     this.classList.toggle('active');
//     var content = this.nextElementSibling;
//     if (content.style.maxHeight){
//       content.style.maxHeight = null;
//     } else {
//       content.style.maxHeight = content.scrollHeight + 'px';
//     }
//   });
// }

// var collapsibles = document.querySelectorAll('[data-collapsible]');

// document
//     .addEventListener('click', function () {
//         for (var i = 0; i < collapsibles.length; ++i) {
//             [collapsibles[i].id].hide();
//         }
//     })

// document
//     .addEventListener('click', function () {
//         [collapsibles[0].id].toggle();
//     })

